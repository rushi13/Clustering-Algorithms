from copy import deepcopy
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

# Importing the dataset
data = pd.read_csv('kmeans-dataset.csv')
print("Input Data and Shape")
print(data.shape)
data.head()

# Getting values from the dataset
names = data.columns
names = names[:-1]
data = data[0:]
gt_labels = data['Classification']

#Data pre-processing
a1 = [np.ndarray.tolist(data[name].values) for name in names]
A = zip(*a1)
X = np.array(list(A))

# Initialize clusters
k = 20
C = np.array(list(zip(np.random.randint(0, 255, size=len(names)) for i in range(k)))) 

# Calculate Distance
def dist(a, b, ax=1):
	ans = []
	for row in b:
		ans.append(np.linalg.norm(a - row))
	return ans

def clusterDist(a, b, ax=1):
	sum = 0
	for row1, row2 in zip(a, b):
		sum += np.linalg.norm(row1 - row2)
	return sum
# Array to store old centroid values
C_old = np.zeros(C.shape)

clusters = np.zeros(len(X))

error = dist(C, C_old, None)

# Loop will run till the error becomes zero
while error != 0:
# Assigning each value to its closest cluster
    for i in range(len(X)):
        distances = dist(X[i], C)		#Get distance of each pt from all centroids
        cluster = distances.index(min(distances)) 	#Select minimum values
        clusters[i] = cluster 			#Assign cluster to the pt
    
    # Storing the old centroid values
    C_old = deepcopy(C)
    
    # Finding the new centroids by taking the average value
    for i in range(k):
        points = [X[j] for j in range(len(X)) if clusters[j] == i] 	# Get co-ordinates for each point in a cluster
        # print(i, points)
        if len(points) != 0:
            C[i] = np.mean(points, axis=0)
        else:
            C[i] = C_old[i]
        # print('clusters', C[i])
        
    error = clusterDist(C, C_old, None)
    #print(error)

clusters = np.int_(clusters)
clusterResult = [0] * k

for i in clusters:
	clusterResult[i] = clusterResult[i] + 1

accuracy = accuracy_score(gt_labels, clusters)
prfs = precision_score(y_true=gt_labels, y_pred=clusters , average=None)
rsc = recall_score(y_true=gt_labels, y_pred=clusters , average=None)
print("Accuracy Score : " , accuracy)
print(" Precision Score : " , prfs)
print(" Recall Score : ", rsc)