import sklearn
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support as calc_metrics
import math
from math import sqrt, pow
import time
import csv

def DistanceBetweenPoints(x, y):
    distance = sqrt(pow((y[0] - x[0]), 2) + pow((y[1] - x[1]), 2) + pow((y[2] - x[2]), 2) + pow((y[3] - x[3]), 2) + pow(
        (y[4] - x[4]), 2) + pow((y[5] - x[5]), 2) + pow((y[6] - x[6]), 2) + pow((y[7] - x[7]), 2) + pow((y[8] - x[8]),2) + pow(
        (y[9] - x[9]), 2) + pow((y[10] - x[10]), 2) + pow((y[11] - x[11]), 2))
    return distance

def RangeQuery(data, i):
    neighbors = []
    for j in range(len(data)):
        distance = DistanceBetweenPoints(data[i], data[j])
        if distance <= eps:
            neighbors.append(data[j])
    return neighbors

def extendClusters(data, eps, min_pts, current_cluster, neighbors, status):
    clusters = []
    for i in range(len(neighbors)):
        for k in range(len(data)):
            if neighbors[i] == data[k] and status[k] == "notVisited":
                status[k] = "visited"
                added_points = RangeQuery(data, i)
                if len(added_points) >= min_pts:
                    for p in added_points:
                        if p not in neighbors:
                            neighbors.append(p)
                if data[i] not in clusters:
                    clusters.append([i,current_cluster])
    return clusters

def dbscan(data, eps, min_pts):
    noise = []
    status = []
    current_cluster = 0
    for i in range(len(data)):
        status.append("notVisited")
    pred_label = []
    for i in range(len(data)):
        if status[i] == "notVisited":
            status[i] = "visited"
            neighbors = RangeQuery(data, i)
            if len(neighbors) >= min_pts:
                current_cluster += 1
                cluster = [data[i], ]
                cluster.extend(extendClusters(data, eps, min_pts, current_cluster, neighbors, status))
                cluster.pop(0)
                pred_label.extend(cluster)
            else:
                noise.append(i)
    return pred_label

if __name__ == '__main__':
    eps = 35
    min_pts = 65
    data = []
    start = time.time()
    f = open('Dataset for dbscan.csv', 'r')
    reader = csv.reader(f, delimiter = ",")
    for line in reader:
        data.append([float(line[0]), float(line[1]), float(line[2]), float(line[3]), float(line[4]), float(line[5]),
                       float(line[6]), float(line[7]), float(line[8]), float(line[9]), float(line[10]),
                       float(line[11])])
    cnum = 1
    size = 55
    for j in range(0,len(data)):
        data[j].append(cnum)
        size -= 1
        if(size == 0):
            cnum += 1
            size = 55
    cnum -= 1
    print("Finished importing data")
    results = dbscan(data, eps, min_pts)
    acc_list = [(0,0) for _ in range(len(results))]
    for m in range(0,len(results)):
        #print(m , ' ' , results[m][1] , ' ' , data[results[m][0]][12])
        templ = (results[m][1] , data[results[m][0]][12])
        acc_list[m] = templ
    gt_labels = []
    for i in range(0,len(acc_list)):
        gt_labels.append(acc_list[i][0])
    pred_labels = []
    for i in range(0,len(acc_list)):
        pred_labels.append(acc_list[i][1])
    acc = accuracy_score(y_true = gt_labels, y_pred = pred_labels)
    precision, recall, fscore, support = calc_metrics(gt_labels, pred_labels, average = "macro", warn_for = "None")
    print("The accuracy obtained is", acc*100)
    print("The precision value is {}" .format(precision))
    print("The recall value is {}".format(recall))
    print("The F-score is {}".format(fscore))
    print("Total time required for execution: %s seconds" % (time.time() - start))	