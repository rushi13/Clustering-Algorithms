from kmedoids import KMedoids
import numpy as np
from datetime import datetime
import warnings
import sklearn.exceptions
from sklearn.metrics import accuracy_score , precision_score , recall_score
import csv
import scipy.spatial.distance as ssd1
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore", category=sklearn.exceptions.UndefinedMetricWarning)

def distance_proc(data1, data2):
    return ssd1.euclidean(data1,data2,None)

if __name__ == '__main__':
    print("Start Time : " , str(datetime.now()))
    a = []
    gt_labels = []
    with open("input1.csv", 'r') as csvfile:
        csvreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
        for row in csvreader:
            temp = row[0].split(',')
            for i in range(0,len(temp)):
                temp[i] = int(temp[i])
            a.append(temp[0:12])
            gt_labels.append(temp[12])
    data_list = np.array(a)

    clusterObj = KMedoids(nclust=20, dist_func=distance_proc)
    op = clusterObj.cluster(data_list, plotit=True, verbose=True)
    pred_labels = op[1].tolist()

    for k in range(0,len(pred_labels)):
        pred_labels[k] = int(pred_labels[k])
    accuracy = accuracy_score(gt_labels, pred_labels)
    prfs = precision_score(y_true=gt_labels, y_pred=pred_labels , average=None)
    rsc = recall_score(y_true=gt_labels, y_pred=pred_labels , average=None)
    print("Accuracy Score : " , accuracy)
    print(" Precision Score : " , prfs)
    print(" Recall Score : ", rsc)
    print("Endtime : ",str(datetime.now()))
    plt.show()
