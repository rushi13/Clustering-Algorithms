
import numpy as np
from copy import deepcopy
import scipy.spatial.distance as ssd
import matplotlib.pyplot as plt

def initialize_centers(nclust, nsamp):
    '''compute initial centers randomly'''
    data_pts = []
    while len(data_pts) < nclust:
        temp = np.random.randint(0, nsamp)
        if not temp in data_pts:
            data_pts.append(temp)
    return data_pts


def _get_distance(data1, data2):
    '''distance function'''
    return ssd.euclidean(data1,data2,None)


def executeKmedoids(data_list, nclust, dist_func, max_iter=2, tolerance=0.001, verbose=True):

    nsamp, nfeat = data_list.shape
    data_pts = initialize_centers(nclust, nsamp)
    centers = data_pts
    clust_mem, cluster_cost, tc, dist_mat = computeIteration(data_list, data_pts, dist_func)
    noofiter, swaped = 0, True
    while True:
        swaped = False
        centers_ = deepcopy(centers)
        clust_mem_, cluster_cost_, tc_, dist_mat_ = computeIteration(data_list, centers_, dist_func)
        if tc_ - tc < tolerance:
            clust_mem, cluster_cost, tc, dist_mat = clust_mem_, cluster_cost_, tc_, dist_mat_
            centers = centers_
            swaped = True
        if noofiter > max_iter or not swaped:
            break
        noofiter += 1
    return centers, clust_mem, cluster_cost, tc, dist_mat

def computeIteration(data_list, centers_id, dist_func):
    '''return total cost ot itertion and cost of each cluster'''
    dist_mat = np.zeros((len(data_list), len(centers_id)))
    for j in range(len(centers_id)):
        center = data_list[centers_id[j], :]
        for i in range(len(data_list)):
            if i == centers_id[j]:
                dist_mat[i, j] = 0.
            else:
                dist_mat[i, j] = dist_func(data_list[i, :], center)
    mask = np.argmin(dist_mat, axis=1)
    clust_mem = np.zeros(len(data_list))
    cluster_cost = np.zeros(len(centers_id))
    for i in range(len(centers_id)):
        mem_id = np.where(mask == i)
        clust_mem[mem_id] = i
        cluster_cost[i] = np.sum(dist_mat[mem_id, i])
    return clust_mem, cluster_cost, np.sum(cluster_cost), dist_mat


class KMedoids(object):


    def __init__(self, nclust, dist_func=_get_distance, max_iter=2, tolerance=0.001):
        self.nclust = nclust
        self.dist_func = dist_func
        self.max_iter = max_iter
        self.tolerance = tolerance

    def cluster(self, data_list, plotit=True, verbose=True):
        centers, clust_mem, cluster_cost, tc, dist_mat = executeKmedoids(
            data_list, self.nclust, self.dist_func, max_iter=self.max_iter, tolerance=self.tolerance, verbose=verbose)

        if plotit:
            clust_fig, adata_list = plt.subplots(1, 1)
            colors = ['xkcd:blue', 'xkcd:orange', 'xkcd:green', 'xkcd:red', 'data_listkcd:purple', 'data_listkcd:brown', 'data_listkcd:pink', 'data_listkcd:gray', 'data_listkcd:olive', 'data_listkcd:cyan' , 'data_listkcd:azure', 'xkcd:ivory', 'xkcd:snot' , 'xkcd:sea', 'xkcd:iris' , 'xkcd:light mint', 'xkcd:mushroom' , 'xkcd:rich blue', 'xkcd: maroon', 'xkcd: sea']
            if self.nclust > len(colors):
                raise ValueError('we need more colors')

        for i in range(len(centers)):
             data_list_c = data_list[clust_mem == i, :]
             adata_list.scatter(data_list_c[:, 0], data_list_c[:, 1], alpha=0.5, s=30)
             adata_list.scatter(data_list[centers[i], 0], data_list[centers[i], 1], alpha=1., s=250, marker='*')

        return centers , clust_mem

