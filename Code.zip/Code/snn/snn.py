from sklearn import preprocessing
import numpy as np
import time
import csv
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

start = time.time()

k = 1  # Nearest Neighbor Size
minPoints = 1  # defines core point
eps = 1  # defines noise
datafile = open("input1.csv")
#lines = [line.split(",") for line in datafile]
temp = []
next(datafile)

temp1 = [[float(n) for n in line.rstrip('\n').split(",")] for line in datafile]

temp = np.array(temp1)

data = temp[:, :11]
gt_labels = temp[:, [12]]
gt_labels = np.int_(gt_labels)
print(gt_labels)

i = 0
j = 0

def eucledian_dist(data1,data2):
    ans = 0
    for i in range(0, len(data1)):
        ans = ans + (data1[i] - data2[j]) ** 2
    ans = ans ** 0.5
    return ans

def computeDistanceMatrix(data):
    distanceMatrix=[[0 for i in range(len(data))] for j in range(len(data))]
    for i in range(0,len(data)):
        for j in range(0,len(data)):
            distanceMatrix[i][j]=((i,j),eucledian_dist(data[i],data[j]))
    return distanceMatrix

def findKNNList(distanceMatrix, k):
    count=len(distanceMatrix)
    # matrix = [[0 for i in range(count)] for j in range(count)]#matrix with dimension count*count
    global similarityMatrix# list to hold k similar indices of points to any point
    count=len(distanceMatrix)
    similarityMatrix = [[0 for i in range(k)] for j in range(count)]
    for i in range(count):
        matrixsorted = sorted(distanceMatrix[i], key=lambda x: x[1])# sort each row of Matrix based on distance(value)
        #print matrixsorted
        for j in range(k):
            #file.write(str(matrixsorted[0][j+1]) + " ")# write all the k nearest neighbors to file
            similarityMatrix[i][j] = int(matrixsorted[j+1][0][1])#Assign each row  in similarityMatrix to all the k nearest neighbors..
    return similarityMatrix

distanceMatrix=computeDistanceMatrix(data)
similarityMatrix=findKNNList(distanceMatrix,8)
count=len(data)

def countIntersection(listi,listj):
    intersection=0
    for i in listi:
        if i in listj:
            intersection=intersection+1
    return intersection

def sharedNearest(count,k):
    Snngraph= [[0 for i in range(count)] for j in range(count)]
    for i in range(0,count-1):
        nextIndex=i+1
        for j in range(nextIndex,count):
            if j in similarityMatrix[i] and i in similarityMatrix[j]:
                count1=countIntersection(similarityMatrix[i],similarityMatrix[j])
                Snngraph[i][j]=count1
                Snngraph[j][i]=count1
    return Snngraph

sharedNearestN= sharedNearest(count,k)

def density(x,eps):
    numbPoints=0
    for i in range(0,count):
        if x[i] >= eps:
            numbPoints=numbPoints+1
    return numbPoints

snnDensity1=[None for i in range(len(sharedNearestN))]

for i in range(len(sharedNearestN)):
        snnDensity1[i]=density(sharedNearestN[i],eps)


def coreornot(x, minPoints):
    if x >= minPoints:
        return True
    else:
        return False


def core(x, y):
    if x >= minPoints:
        return y
    else:
        return None


coreOrNot = [None for i in range(len(snnDensity1))]
for i in range(len(snnDensity1)):
    coreOrNot[i] = coreornot(snnDensity1[i], minPoints)
corePointsList1 = []
snnDensity2 = zip(snnDensity1, [i for i in range(len(snnDensity1))])
for i in range(len(snnDensity2)):
    corePointsList1.append(core(snnDensity2[i][0], snnDensity2[i][1]))
corePointsList = [x for x in corePointsList1 if x != None]  # list of core points


def findCoreNeighbors(p, corePts, sharednearestNeighbors, eps):
    coreNeighbors = []
    p2 = None

    for i in range(0, len(corePts)):
        p2 = corePts[i]
        # if two core points share more than eps neighbors make the core point core nearest neighbor of other
        if (p != p2 and sharednearestNeighbors[p][p2] >= eps):
            coreNeighbors.append(p2)
    return coreNeighbors


def expandCluster(labels, neighborCore, corePts, C, sharednearestNeighbors, eps, visited):
    while len(neighborCore) > 0:
        p = neighborCore.pop(0)
        if p in visited:
            continue
        labels[p] = C
        visited.append(p)
        neighCore = findCoreNeighbors(p, corePts, sharednearestNeighbors, eps)
        neighborCore.extend(neighCore)
    return labels


visited = []  # list to store points visited
labels = [0 for i in range(count)]
neighborCore = []  # neighborss of core points
c = 0

for i in range(0, len(corePointsList)):
    p = corePointsList[i]
    if p in visited:
        continue
    visited.append(p)
    c = c + 1
    labels[p] = c

    neighborCore = findCoreNeighbors(p, corePointsList, sharedNearestN, eps)
    labels = expandCluster(labels, neighborCore, corePointsList, c, sharedNearestN, eps, visited)

for i in range(count):
    notNoise=False
    maxSim=2**31-1
    bestCore=-1
    sim=None
    if(coreOrNot[i]):#core Point
        continue
    for j in range(len(corePointsList)):
        p=corePointsList[j]
        #sharedNearestN contains count of shared neighbors between points
        # sim gives the similarity  between core point and the other point.
        sim=sharedNearestN[i][p]
        # if sim is greater than eps--> the point is not a noise
        if(sim>=eps):
            notNoise=True
         # if sim is less than eps--> the point is  a noise point assign cluster index 0 to it
        else:
            labels[i]=0
            break
        #Here we attempt to see to which core point does the non-core point has maximum similarity
        if(sim>maxSim):
            maxSim=sim
            bestCore=p
        #End of inner for loop
    #for each non-core point assign the index of core point with which the point has maximum similarity
    if(notNoise):
        labels[i]=labels[bestCore]

print(len(labels))
print(len(gt_labels))

accuracy = accuracy_score(gt_labels, labels)
prfs = precision_score(y_true=gt_labels, y_pred=labels , average=None)
rsc = recall_score(y_true=gt_labels, y_pred=labels , average=None)
print("Accuracy Score : " , accuracy)
print(" Precision Score : " , prfs)
print(" Recall Score : ", rsc)



for i in range(0,len(labels)):
    if(labels[i] <> 0):
        print(labels[i])
